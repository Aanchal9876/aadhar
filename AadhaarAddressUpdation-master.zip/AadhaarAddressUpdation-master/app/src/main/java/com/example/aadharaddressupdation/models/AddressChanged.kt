package com.example.aadharaddressupdation.models

data class AddressChanged(val appliedBy:String,val approvedBy:String)