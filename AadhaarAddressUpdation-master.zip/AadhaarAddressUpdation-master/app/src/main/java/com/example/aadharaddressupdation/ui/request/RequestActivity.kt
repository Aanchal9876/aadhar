package com.example.aadharaddressupdation.ui.request

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aadharaddressupdation.R

class RequestActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request)
    }
}